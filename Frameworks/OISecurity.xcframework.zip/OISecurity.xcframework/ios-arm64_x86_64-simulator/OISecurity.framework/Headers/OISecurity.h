//
//  OISecurity.h
//  OISecurity
//

#import <Foundation/Foundation.h>

//! Project version number for OISecurity.
FOUNDATION_EXPORT double OISecurityVersionNumber;

//! Project version string for OISecurity.
FOUNDATION_EXPORT const unsigned char OISecurityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <OISecurity/PublicHeader.h>


